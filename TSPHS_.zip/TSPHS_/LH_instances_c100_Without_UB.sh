./VRPSolver data/instancias_c100/h05_c100_l150_01.txt -O 1 -O 1 -q 12 > out/instancias_c100/h05_c100_l150_01_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_02.txt -O 1 -q 13 > out/instancias_c100/h05_c100_l150_02_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_03.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_03_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_04.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_04_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_05.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_05_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_06.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_06_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_07.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_07_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_08.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_08_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_09.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_09_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l150_10.txt -O 1 -q 12 > out/instancias_c100/h05_c100_l150_10_Without_UB_.out
     
./VRPSolver data/instancias_c100/h05_c100_l200_01.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_01_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_02.txt -O 1 -q 10 > out/instancias_c100/h05_c100_l200_02_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_03.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_03_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_04.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_04_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_05.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_05_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_06.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_06_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_07.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_07_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_08.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_08_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_09.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_09_Without_UB_.out
./VRPSolver data/instancias_c100/h05_c100_l200_10.txt -O 1 -q 9 > out/instancias_c100/h05_c100_l200_10_Without_UB_.out

./VRPSolver data/instancias_c100/h10_c100_l100_01.txt -O 1 -q 18 > out/instancias_c100/h10_c100_l100_01_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l100_06.txt -O 1 -q 18 > out/instancias_c100/h10_c100_l100_06_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l100_07.txt -O 1 -q 18 > out/instancias_c100/h10_c100_l100_07_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l100_08.txt -O 1 -q 18 > out/instancias_c100/h10_c100_l100_08_Without_UB_.out

       
./VRPSolver data/instancias_c100/h10_c100_l150_01.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_01_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_02.txt -O 1 -q 13 > out/instancias_c100/h10_c100_l150_02_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_03.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_03_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_04.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_04_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_05.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_05_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_06.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_06_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_07.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_07_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_08.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_08_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_09.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_09_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l150_10.txt -O 1 -q 12 > out/instancias_c100/h10_c100_l150_10_Without_UB_.out
     
     
./VRPSolver data/instancias_c100/h10_c100_l200_01.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_01_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_02.txt -O 1 -q 10 > out/instancias_c100/h10_c100_l200_02_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_03.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_03_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_04.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_04_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_05.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_05_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_06.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_06_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_07.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_07_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_08.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_08_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_09.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_09_Without_UB_.out
./VRPSolver data/instancias_c100/h10_c100_l200_10.txt -O 1 -q 9 > out/instancias_c100/h10_c100_l200_10_Without_UB_.out
     
     
./VRPSolver data/instancias_c100/h20_c100_l100_01.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_01_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_02.txt -O 1 -q 19 > out/instancias_c100/h20_c100_l100_02_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_03.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_03_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_04.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_04_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_05.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_05_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_06.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_06_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_07.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_07_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_08.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_08_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_09.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_09_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l100_10.txt -O 1 -q 18 > out/instancias_c100/h20_c100_l100_10_Without_UB_.out
     
     
./VRPSolver data/instancias_c100/h20_c100_l150_01.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_01_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_02.txt -O 1 -q 13 > out/instancias_c100/h20_c100_l150_02_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_03.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_03_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_04.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_04_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_05.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_05_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_06.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_06_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_07.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_07_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_08.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_08_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_09.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_09_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l150_10.txt -O 1 -q 12 > out/instancias_c100/h20_c100_l150_10_Without_UB_.out
     
     
./VRPSolver data/instancias_c100/h20_c100_l200_01.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_01_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_02.txt -O 1 -q 10 > out/instancias_c100/h20_c100_l200_02_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_03.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_03_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_04.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_04_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_05.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_05_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_06.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_06_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_07.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_07_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_08.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_08_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_09.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_09_Without_UB_.out
./VRPSolver data/instancias_c100/h20_c100_l200_10.txt -O 1 -q 9 > out/instancias_c100/h20_c100_l200_10_Without_UB_.out

