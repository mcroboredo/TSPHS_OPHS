./VRPSolver data/SET_2-3_TSP/eil51-H4-T3-S3.ophs -t tex/SET_2-3_TSP/eil51-H4-T3-S3.tex -o sol/SET_2-3_TSP/eil51-H4-T3-S3.sol -u -2470 > out/SET_2-3_TSP/eil51-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/berlin52-H4-T3-S3.ophs -t tex/SET_2-3_TSP/berlin52-H4-T3-S3.tex -o sol/SET_2-3_TSP/berlin52-H4-T3-S3.sol -u -2690 > out/SET_2-3_TSP/berlin52-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/st70-H4-T3-S3.ophs -t tex/SET_2-3_TSP/st70-H4-T3-S3.tex -o sol/SET_2-3_TSP/st70-H4-T3-S3.sol -u -3300 > out/SET_2-3_TSP/st70-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/eil76-H4-T3-S3.ophs -t tex/SET_2-3_TSP/eil76-H4-T3-S3.tex -o sol/SET_2-3_TSP/eil76-H4-T3-S3.sol -u -4180 > out/SET_2-3_TSP/eil76-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/pr76-H4-T3-S3.ophs -t tex/SET_2-3_TSP/pr76-H4-T3-S3.tex -o sol/SET_2-3_TSP/pr76-H4-T3-S3.sol -u -3800 > out/SET_2-3_TSP/pr76-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/kroa100-H4-T3-S3.ophs -t tex/SET_2-3_TSP/kroa100-H4-T3-S3.tex -o sol/SET_2-3_TSP/kroa100-H4-T3-S3.sol -u -4630 > out/SET_2-3_TSP/kroa100-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/kroc100-H4-T3-S3.ophs -t tex/SET_2-3_TSP/kroc100-H4-T3-S3.tex -o sol/SET_2-3_TSP/kroc100-H4-T3-S3.sol -u -4350 > out/SET_2-3_TSP/kroc100-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/krod100-H4-T3-S3.ophs -t tex/SET_2-3_TSP/krod100-H4-T3-S3.tex -o sol/SET_2-3_TSP/krod100-H4-T3-S3.sol -u -4510 > out/SET_2-3_TSP/krod100-H4-T3-S3.out
./VRPSolver data/SET_2-3_TSP/rd100-H4-T3-S3.ophs -t tex/SET_2-3_TSP/rd100-H4-T3-S3.tex -o sol/SET_2-3_TSP/rd100-H4-T3-S3.sol -u -4870 > out/SET_2-3_TSP/rd100-H4-T3-S3.out
./VRPSolver data/SET_4-4_TSP/eil51-H6-T4-S3.ophs -t tex/SET_4-4_TSP/eil51-H6-T4-S3.tex -o sol/SET_4-4_TSP/eil51-H6-T4-S3.sol -u -2360 > out/SET_4-4_TSP/eil51-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/berlin52-H6-T4-S3.ophs -t tex/SET_4-4_TSP/berlin52-H6-T4-S3.tex -o sol/SET_4-4_TSP/berlin52-H6-T4-S3.sol -u -2620 > out/SET_4-4_TSP/berlin52-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/st70-H6-T4-S3.ophs -t tex/SET_4-4_TSP/st70-H6-T4-S3.tex -o sol/SET_4-4_TSP/st70-H6-T4-S3.sol -u -3300 > out/SET_4-4_TSP/st70-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/eil76-H6-T4-S3.ophs -t tex/SET_4-4_TSP/eil76-H6-T4-S3.tex -o sol/SET_4-4_TSP/eil76-H6-T4-S3.sol -u -4100 > out/SET_4-4_TSP/eil76-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/pr76-H6-T4-S3.ophs -t tex/SET_4-4_TSP/pr76-H6-T4-S3.tex -o sol/SET_4-4_TSP/pr76-H6-T4-S3.sol -u -3600 > out/SET_4-4_TSP/pr76-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/kroa100-H6-T4-S3.ophs -t tex/SET_4-4_TSP/kroa100-H6-T4-S3.tex -o sol/SET_4-4_TSP/kroa100-H6-T4-S3.sol -u -4260 > out/SET_4-4_TSP/kroa100-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/kroc100-H6-T4-S3.ophs -t tex/SET_4-4_TSP/kroc100-H6-T4-S3.tex -o sol/SET_4-4_TSP/kroc100-H6-T4-S3.sol -u -4090 > out/SET_4-4_TSP/kroc100-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/krod100-H6-T4-S3.ophs -t tex/SET_4-4_TSP/krod100-H6-T4-S3.tex -o sol/SET_4-4_TSP/krod100-H6-T4-S3.sol -u -4260 > out/SET_4-4_TSP/krod100-H6-T4-S3.out
./VRPSolver data/SET_4-4_TSP/rd100-H6-T4-S3.ophs -t tex/SET_4-4_TSP/rd100-H6-T4-S3.tex -o sol/SET_4-4_TSP/rd100-H6-T4-S3.sol -u -4490 > out/SET_4-4_TSP/rd100-H6-T4-S3.out
./VRPSolver data/SET_8-4_TSP/eil51-H10-T4-S4.ophs -t tex/SET_8-4_TSP/eil51-H10-T4-S4.tex -o sol/SET_8-4_TSP/eil51-H10-T4-S4.sol -u -2600 > out/SET_8-4_TSP/eil51-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/berlin52-H10-T4-S4.ophs -t tex/SET_8-4_TSP/berlin52-H10-T4-S4.tex -o sol/SET_8-4_TSP/berlin52-H10-T4-S4.sol -u -2630 > out/SET_8-4_TSP/berlin52-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/st70-H10-T4-S4.ophs -t tex/SET_8-4_TSP/st70-H10-T4-S4.tex -o sol/SET_8-4_TSP/st70-H10-T4-S4.sol -u -3270 > out/SET_8-4_TSP/st70-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/eil76-H10-T4-S4.ophs -t tex/SET_8-4_TSP/eil76-H10-T4-S4.tex -o sol/SET_8-4_TSP/eil76-H10-T4-S4.sol -u -4290 > out/SET_8-4_TSP/eil76-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/pr76-H10-T4-S4.ophs -t tex/SET_8-4_TSP/pr76-H10-T4-S4.tex -o sol/SET_8-4_TSP/pr76-H10-T4-S4.sol -u -3660 > out/SET_8-4_TSP/pr76-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/kroa100-H10-T4-S4.ophs -t tex/SET_8-4_TSP/kroa100-H10-T4-S4.tex -o sol/SET_8-4_TSP/kroa100-H10-T4-S4.sol -u -4590 > out/SET_8-4_TSP/kroa100-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/kroc100-H10-T4-S4.ophs -t tex/SET_8-4_TSP/kroc100-H10-T4-S4.tex -o sol/SET_8-4_TSP/kroc100-H10-T4-S4.sol -u -4610 > out/SET_8-4_TSP/kroc100-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/krod100-H10-T4-S4.ophs -t tex/SET_8-4_TSP/krod100-H10-T4-S4.tex -o sol/SET_8-4_TSP/krod100-H10-T4-S4.sol -u -4720 > out/SET_8-4_TSP/krod100-H10-T4-S4.out
./VRPSolver data/SET_8-4_TSP/rd100-H10-T4-S4.ophs -t tex/SET_8-4_TSP/rd100-H10-T4-S4.tex -o sol/SET_8-4_TSP/rd100-H10-T4-S4.sol -u -4890 > out/SET_8-4_TSP/rd100-H10-T4-S4.out
./VRPSolver data/SET_9-7_TSP/eil51-H11-T7-S3.ophs -t tex/SET_9-7_TSP/eil51-H11-T7-S3.tex -o sol/SET_9-7_TSP/eil51-H11-T7-S3.sol -u -2240 > out/SET_9-7_TSP/eil51-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/berlin52-H11-T7-S3.ophs -t tex/SET_9-7_TSP/berlin52-H11-T7-S3.tex -o sol/SET_9-7_TSP/berlin52-H11-T7-S3.sol -u -2930 > out/SET_9-7_TSP/berlin52-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/st70-H11-T7-S3.ophs -t tex/SET_9-7_TSP/st70-H11-T7-S3.tex -o sol/SET_9-7_TSP/st70-H11-T7-S3.sol -u -2970 > out/SET_9-7_TSP/st70-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/eil76-H11-T7-S3.ophs -t tex/SET_9-7_TSP/eil76-H11-T7-S3.tex -o sol/SET_9-7_TSP/eil76-H11-T7-S3.sol -u -3800 > out/SET_9-7_TSP/eil76-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/pr76-H11-T7-S3.ophs -t tex/SET_9-7_TSP/pr76-H11-T7-S3.tex -o sol/SET_9-7_TSP/pr76-H11-T7-S3.sol -u -3510 > out/SET_9-7_TSP/pr76-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/kroa100-H11-T7-S3.ophs -t tex/SET_9-7_TSP/kroa100-H11-T7-S3.tex -o sol/SET_9-7_TSP/kroa100-H11-T7-S3.sol -u -4270 > out/SET_9-7_TSP/kroa100-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/kroc100-H11-T7-S3.ophs -t tex/SET_9-7_TSP/kroc100-H11-T7-S3.tex -o sol/SET_9-7_TSP/kroc100-H11-T7-S3.sol -u -4140 > out/SET_9-7_TSP/kroc100-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/krod100-H11-T7-S3.ophs -t tex/SET_9-7_TSP/krod100-H11-T7-S3.tex -o sol/SET_9-7_TSP/krod100-H11-T7-S3.sol -u -4020 > out/SET_9-7_TSP/krod100-H11-T7-S3.out
./VRPSolver data/SET_9-7_TSP/rd100-H11-T7-S3.ophs -t tex/SET_9-7_TSP/rd100-H11-T7-S3.tex -o sol/SET_9-7_TSP/rd100-H11-T7-S3.sol -u -4780 > out/SET_9-7_TSP/rd100-H11-T7-S3.out






